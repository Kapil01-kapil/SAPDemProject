/* global QUnit */

sap.ui.require(["splitapp/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
