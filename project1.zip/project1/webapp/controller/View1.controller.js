sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel) {
        "use strict";

        return Controller.extend("project1.controller.View1", {
            onInit: function () {
                var oData = {
                    Products: [
                        { A: 0, B: 0, C: 0, GST: 0, Total: 0 },
                        { A: 0, B: 0, C: 0, GST: 0, Total: 0 },
                        { A: 0, B: 0, C: 0, GST: 0, Total: 0 },
                        { A: 0, B: 0, C: 0, GST: 0, Total: 0 }
                    ]
                };
    
                var oModel = new JSONModel(oData);
                this.getView().setModel(oModel);
            },
    
            onInputChange: function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getBindingContext();
                var oProduct = oContext.getObject();
    
                var A = parseFloat(oProduct.A) || 0;
                var B = parseFloat(oProduct.B) || 0;
                var C = parseFloat(oProduct.C) || 0;
    
                var total = A + B + C;
                var gst = total * 0.18; // 18% GST
    
                oProduct.GST = gst.toFixed(2);
                oProduct.Total = (total + gst).toFixed(2);
    
                oModel.refresh();
            },
    
            formatGSTColor: function (gst) {
                console.log("gst==>",gst);
                gst = parseFloat(gst);
                if (gst > 100) {
                    return "highlightGSTHigh";
                } else if (gst > 0) {
                    return "highlightGSTLow";
                } else {
                    return "highlightGSTHigh";
                }
            },
    
            formatTotalColor: function (total) {
                return parseFloat(total) > 1000 ? "highlightTotalHigh" : "highlightGSTHigh";
            }
        });
    });
